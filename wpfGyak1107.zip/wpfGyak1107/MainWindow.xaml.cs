﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpfGyak1107
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Organization> organisations = new List<Organization>();
        private void Betolt(string fileName)
        {
            foreach (var sor in File.ReadAllLines(fileName).Skip(1))
            {
                organisations.Add(new Organization(sor.Split(';')));
            }

        }
        public MainWindow()
        {
            InitializeComponent();
            Betolt("organizations-100.csv");
            dgAdatok.ItemsSource = organisations;

            cbOrszag.ItemsSource = organisations.Select(x => x.Country).OrderBy(x => x).Distinct().ToList();

            cbEv.ItemsSource = organisations.Select(x => x.Founded).OrderBy(x => x).Distinct().ToList();

            lblEmployeeNum.Content = organisations.Sum(x => x.EmployeesNumber);
        }

        private void cbOrszag_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var filteredList = organisations.Where(x => x.Country == cbOrszag.SelectedItem.ToString());

            if (cbOrszag.SelectedItem == "Összes Ország")
            {
                filteredList = organisations;
            }


            if (cbEv.SelectedIndex != 0)
            {
                filteredList.Where(x => x.Founded.ToString() == cbEv.SelectedItem.ToString());
            }


            dgAdatok.ItemsSource = filteredList;
            lblEmployeeNum.Content = filteredList.Sum(x => x.EmployeesNumber);
        }

        private void cbEv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var filteredList = organisations.Where(x => x.Founded.ToString() == cbEv.SelectedItem.ToString());

            if (cbEv.SelectedItem == "Összes Év")
            {
                filteredList = organisations;
            }

            if (cbOrszag.SelectedIndex != 0)
            {
                filteredList.Where(x => x.Country == cbOrszag.SelectedItem.ToString());
            }

            dgAdatok.ItemsSource = filteredList;
            lblEmployeeNum.Content = filteredList.Sum(x => x.EmployeesNumber);
        }

        private void dgAdatok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgAdatok.SelectedItem is Organization)
            {
                Organization selectedOb = dgAdatok.SelectedItem as Organization;
                lblAzonosito.Content = selectedOb.Id.ToString();
                lblWebcim.Content = selectedOb.Website;
                lblIsmerteto.Content = selectedOb.Description;
            }
            else
            {
                MessageBox.Show("Hiba!");
            }
        }
    }
}
